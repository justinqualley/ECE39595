#include<iostream>
#include "LaysEggs.h"
#include "DoesNotLayEggs.h"

void DoesNotLayEggs::laysEgg(){
    std::cout << "Not an egg layer." << std::endl;
}
