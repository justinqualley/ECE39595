#ifndef LAYEGGS_H_
#define LAYEGGS_H_

class LaysEggs {
public:
   virtual void laysEgg( ) = 0;
};
#endif /* LAYEGGS_H_ */
