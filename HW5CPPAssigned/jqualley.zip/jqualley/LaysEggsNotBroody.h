#ifndef LAYEGGSNOTBROODY_H_
#define LAYEGGSNOTBROODY_H_
#include "LaysEggs.h"
class LaysEggsNotBroody : public LaysEggs {
public:
    void laysEgg();
};
#endif
