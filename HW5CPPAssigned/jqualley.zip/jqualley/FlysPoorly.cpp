#include<iostream>
#include "FlysPoorly.h"

void FlysPoorly::fly(){
    std::cout << "flies poorly" << std::endl;
}
