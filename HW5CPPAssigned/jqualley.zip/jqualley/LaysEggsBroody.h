#ifndef LAYEGGSBROODY_H_
#define LAYEGGSBROODY_H_
#include "LaysEggs.h"
class LaysEggsBroody : public LaysEggs {
public:
    void laysEgg();
};
#endif 
