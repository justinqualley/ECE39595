#include <string>
#include <sstream>
#include <iostream>
#include "Automobile.h"
//vehicle identification number that can be represented as an integer, miles driven, which can be represented as a float, 
//and the date of the last maintenance, which should be stored as a string.
Automobile::Automobile(int VIN, float miles, int mm, int dd, int yy){
    _VIN_ = VIN;
    _miles_ = miles;
    _mm_ = mm;
    _dd_ = dd;
    _yy_ = yy;
}

std::string Automobile::toString( ) {
    std::ostringstream m;
    m << _miles_;
    std::string str = "VIN: "+std::to_string(_VIN_) +"\n";
    str += "Miles Driven: "+m.str()+"\n";
    str += "Maintenance Date: "+setDate(_mm_,_dd_,_yy_)+"\n";
    return str;
}

std::string Automobile::setDate(int mm, int dd, int yy){
    std::string maint;
    maint = ""+std::to_string(mm)+"/"+std::to_string(dd)+"/"+std::to_string(yy);
    return maint;
}

