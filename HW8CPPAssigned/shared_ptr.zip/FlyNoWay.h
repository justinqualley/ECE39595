#ifndef FLYNOWAY_H_
#define FLYNOWAY_H_
#include "FlyBehavior.h"

class FlyNoWay : public FlyBehavior {
public:
   void fly( );
};
#endif /* FLYNOWAY_H_ */
