#ifndef MALLARDDUCK_H_
#define MALLARDDUCK_H_
#include "Duck.h"

class MallardDuck : public Duck {
public:
   MallardDuck( );
   void display( );
   virtual ~MallardDuck();
};
#endif /* MALLARDDUCK_H_ */
