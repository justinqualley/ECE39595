#include <iostream>
#include "FlyWithWings.h"

void FlyWithWings::fly( ) {
   std::cout << "Fly, fly!" << std::endl;
}
FlyWithWings::~FlyWithWings(){}
